const BASE_URL = 'http://localhost:8080/api';

// Fetch and display all movies
async function fetchMovies() {
    const response = await fetch(`${BASE_URL}/movies`);
    const movies = await response.json();

    let movieSeatsHTML = '';
    movies.forEach(movie => {
        movieSeatsHTML += `
            <div>
                <h3>${movie.name}</h3>
                <p>Showtime: ${movie.showTime}</p>
                <p>Available Seats: ${movie.availableSeats}</p>
                <p><strong>ID:</strong> ${movie.id}</p>
            </div>
        `;
    });

    document.getElementById('movieList').innerHTML = movieSeatsHTML;
}

// Handle ticket booking
async function bookTicket(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const creditCard = document.getElementById('creditCard').value;
    const movieName = document.getElementById('movieName').value;

    const requestBody = {
        username: username,
        creditCardNumber: creditCard,
        movieName: movieName
    };

    const response = await fetch(`${BASE_URL}/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
    });

    const result = await response.json();

    if (response.ok) {
        alert(`✅ Ticket Booked! Booking ID: ${result.bookingId}`);
    } else {
        alert(`❌ Error: ${result.error}`);
    }

    fetchMovies();
}

// Handle booking cancellation
async function cancelBooking(event) {
    event.preventDefault();

    const bookingId = prompt("Enter the Booking ID to cancel:");
    if (!bookingId) {
        alert("Booking ID is required.");
        return;
    }

    const response = await fetch(`${BASE_URL}/bookings/${bookingId}`, {
        method: 'DELETE'
    });

    const result = await response.json();

    if (response.ok) {
        alert(`🗑️ Booking Cancelled`);
    } else {
        alert(`❌ Error: ${result.error}`);
    }

    fetchMovies();
}

// Init
document.addEventListener('DOMContentLoaded', function () {
    fetchMovies();
    document.getElementById('bookingForm').addEventListener('submit', bookTicket);
    document.getElementById('cancelForm').addEventListener('submit', cancelBooking);
});
