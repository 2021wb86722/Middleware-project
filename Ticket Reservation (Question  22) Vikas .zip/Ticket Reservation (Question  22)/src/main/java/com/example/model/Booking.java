package com.example.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "bookings")
public class Booking {
    @Id
    private String id;
    private String username;
    private String movieName;
    private String creditCardNumber;
    private LocalDateTime bookingTime;

    public Booking() {}

    public Booking(String id, String username, String movieName, String creditCardNumber, LocalDateTime bookingTime) {
        this.id = id;
        this.username = username;
        this.movieName = movieName;
        this.creditCardNumber = creditCardNumber;
        this.bookingTime = bookingTime;
    }

    // Getters and Setters
    // ...
    public String getId() {
    return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public LocalDateTime getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(LocalDateTime bookingTime) {
        this.bookingTime = bookingTime;
    }

}
