package com.example.model;

public class TicketBookingRequest {
    private String username;
    private String creditCardNumber;
    private String movieName;

    public TicketBookingRequest() {}

    public TicketBookingRequest(String username, String creditCardNumber) {
        this.username = username;
        this.creditCardNumber = creditCardNumber;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }
}
