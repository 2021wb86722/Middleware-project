package com.example.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "movies")
public class Movie {
    @Id
    private String id;
    private String name;
    private String showTime;
    private int availableSeats;

    public Movie() {}

    public Movie(String id, String name, String showTime, int availableSeats) {
        this.id = id;
        this.name = name;
        this.showTime = showTime;
        this.availableSeats = availableSeats;
    }

    // Getters and Setters
    // ...
    public String getId() {
    return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShowTime() {
        return showTime;
    }

    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
}
