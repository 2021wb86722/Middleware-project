package com.example.service;

import com.example.model.Booking;
import com.example.model.Movie;
import com.example.repository.BookingRepository;
import com.example.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private MovieRepository movieRepo;

    public Booking bookTicket(String username, String movieName, String creditCard) {
        Movie movie = movieRepo.findByName(movieName)
                .orElseThrow(() -> new RuntimeException("Movie not found"));

        if (movie.getAvailableSeats() <= 0)
            throw new RuntimeException("No seats available");

        movie.setAvailableSeats(movie.getAvailableSeats() - 1);
        movieRepo.save(movie);

        Booking booking = new Booking(null, username, movieName, creditCard, LocalDateTime.now());
        return bookingRepo.save(booking);
    }

    public void cancelBooking(String bookingId) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        Movie movie = movieRepo.findByName(booking.getMovieName())
                .orElseThrow(() -> new RuntimeException("Movie not found"));

        movie.setAvailableSeats(movie.getAvailableSeats() + 1);
        movieRepo.save(movie);
        bookingRepo.deleteById(bookingId);
    }
}
