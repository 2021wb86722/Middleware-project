package com.example;

import com.example.model.Movie;
import com.example.repository.MovieRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TicketReservationApplication {
    public static void main(String[] args) {
        SpringApplication.run(TicketReservationApplication.class, args);
    }

    @Bean
    CommandLineRunner init(MovieRepository movieRepository) {
        return args -> {
            movieRepository.deleteAll();
            movieRepository.save(new Movie(null, "Mission Impossible ", "2025-07-01 10:00", 50));
            movieRepository.save(new Movie(null, "Avangers: Endgame", "2019-12-29 14:00", 40));
            movieRepository.save(new Movie(null, "Lucifer", "2025-07-01 16:00", 30));
            movieRepository.save(new Movie(null, "Helo", "2024-04-17 09:00", 100));
            movieRepository.save(new Movie(null, "Top gun: Maverick", "2022-05-24 10:00", 120));
            movieRepository.save(new Movie(null, "Jurassic world", "2025-11-19 11:00", 80));
        };
    }
}
