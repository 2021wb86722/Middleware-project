package com.example.controller;

import com.example.model.TicketBookingRequest;
import com.example.service.BookingService;
import com.example.model.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<?> book(@RequestBody TicketBookingRequest request) {
        try {
            Booking booking = bookingService.bookTicket(
                    request.getUsername(),
                    request.getMovieName(),
                    request.getCreditCardNumber()
            );
            return ResponseEntity.ok(Map.of(
                    "status", "success",
                    "bookingId", booking.getId()
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancel(@PathVariable String id) {
        bookingService.cancelBooking(id);
        return ResponseEntity.ok(Map.of("status", "cancelled"));
    }
}
