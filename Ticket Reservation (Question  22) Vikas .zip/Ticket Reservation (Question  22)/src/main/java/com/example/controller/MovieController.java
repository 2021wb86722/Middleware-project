package com.example.controller;

import com.example.model.Movie;
import com.example.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/movies")
public class MovieController {
    @Autowired
    private MovieService movieService;

    @GetMapping
    public List<Movie> getAllMovies() {
        return movieService.getAllMovies();
    }

    @GetMapping("/{id}")
    public Movie getMovie(@PathVariable String id) {
        return movieService.getMovieById(id).orElse(null);
    }

    @GetMapping("/{id}/seats")
    public Map<String, Integer> getSeats(@PathVariable String id) {
        return movieService.getMovieById(id)
                .map(m -> Map.of("availableSeats", m.getAvailableSeats()))
                .orElse(Map.of("availableSeats", -1));
    }
}
