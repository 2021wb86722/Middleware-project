package com.example;

import com.example.service.MovieService;
import com.example.controller.BookingController;
import com.example.model.TicketBookingRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class TicketServiceTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MovieService movieService;

    @Autowired
    private BookingController bookingController;

    @Test
    public void testAvailableSeats() throws Exception {
        mockMvc.perform(get("/tickets/available-seats"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].availableSeats").value(50));
    }

    @Test
    public void testBookTicket() throws Exception {
        TicketBookingRequest request = new TicketBookingRequest("testUser", "1234567890123456");

        mockMvc.perform(post("/tickets/book")
                .param("movieName", "Inception")
                .contentType("application/json")
                .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Ticket booked successfully")));
    }

    @Test
    public void testCancelBooking() throws Exception {
        // Book a ticket first
        movieService.getMovieByName("Inception").ifPresent(movie -> movie.setAvailableSeats(movie.getAvailableSeats() - 1));

        // Cancel it
        mockMvc.perform(delete("/tickets/cancel/1")
                .param("movieName", "Inception"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Booking for Inception cancelled")));
    }
}
